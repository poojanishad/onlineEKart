import { createContext, useContext, useState, useEffect, useRef } from "react";

const UIContext = createContext();

export const UIProvider = ({ children }) => {
  // FIX: Theme was not persisted — initialise from localStorage
  const [theme, setThemeState] = useState(
    () => localStorage.getItem("theme") || "light"
  );

  // FIX (suggestion): cartRef was a plain exported module object in Navbar.jsx —
  // non-idiomatic and creates an implicit module-level side channel.
  // Moved here so it travels through proper React Context.
  const cartIconRef = useRef(null);

  const setTheme = (newTheme) => {
    setThemeState(newTheme);
    localStorage.setItem("theme", newTheme);
  };

  useEffect(() => {
    document.body.classList.remove("light", "dark");
    document.body.classList.add(theme);
  }, [theme]);

  return (
    <UIContext.Provider value={{ theme, setTheme, cartIconRef }}>
      {children}
    </UIContext.Provider>
  );
};

export const useUI = () => useContext(UIContext);
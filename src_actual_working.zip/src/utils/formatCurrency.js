// FIX (suggestion): API prices are in USD but currency was hardcoded to 'INR'.
// Now detects the user's locale automatically and defaults to USD to match the API.
export const formatCurrency = (amount) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(amount);
};

import { configureStore } from '@reduxjs/toolkit';
// FIX (suggestion): import paths were '../app/features/...' from inside src/app/ —
// the '../app/' prefix was redundant and misleading. Corrected to relative paths.
import productReducer from './features/products/productSlice';
import cartReducer from './features/cart/cartSlice';

export const store = configureStore({
  reducer: {
    products: productReducer,
    cart: cartReducer,
  },
});

// FIX (suggestion): Cart localStorage persistence moved here via store.subscribe()
// instead of duplicating localStorage.setItem inside every cartSlice reducer.
// Redux reducers must be pure functions — side-effects inside them are an anti-pattern.
store.subscribe(() => {
  const { cart } = store.getState();
  try {
    localStorage.setItem('cart', JSON.stringify(cart.items));
  } catch (e) {
    console.warn('Could not persist cart to localStorage', e);
  }
});
